package com.example.rascunho;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private RadioGroup RG,RG2,RG3;
    private CheckBox CheckIng,CheckFran,CheckEsp,CheckOut,CheckPot;
    private ImageView SimIng,SimF,SimE,SimO,SimP,NIng,NFran,NEsp,NOut,NPot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AlertDialog.Builder Alerta = new AlertDialog.Builder(this);
        Alerta.setTitle("Aviso importante")
                .setMessage("Escolha ao menos uma das opções, por favor!");
        Alerta.show();

        RG=findViewById(R.id.RG);
        RG2=findViewById(R.id.RG2);
        RG3=findViewById(R.id.RG3);
        CheckIng=findViewById(R.id.CheckIng);
        CheckFran=findViewById(R.id.CheckFran);
        CheckEsp=findViewById(R.id.CheckEsp);
        CheckOut=findViewById(R.id.CheckOut);
        CheckPot=findViewById(R.id.CheckPort);
        SimIng=findViewById(R.id.SimIng);
        NIng=findViewById(R.id.NIng);
        SimF=findViewById(R.id.SimF);
        NFran=findViewById(R.id.NFra);
        SimE=findViewById(R.id.SimE);
        NEsp=findViewById(R.id.NEsp);
        SimO=findViewById(R.id.SimO);
        NOut=findViewById(R.id.NOut);
        SimP=findViewById(R.id.SimP);
        NPot=findViewById(R.id.NPot);

        Ing();
        Fra();
        Esp();
        Out();
        Pot();
    }

    public void Mostrar(View view){
        RG.setVisibility(View.VISIBLE);
        RG2.setVisibility(View.VISIBLE);
        RG3.setVisibility(View.VISIBLE);
    }
    public void Esconder(View view){
        RG.setVisibility(View.INVISIBLE);
        RG2.setVisibility(View.INVISIBLE);
        RG3.setVisibility(View.INVISIBLE);
    }
    public void Ing(){
        CheckIng.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(CheckIng.isChecked()){
            SimIng.setVisibility(View.VISIBLE);
            NIng.setVisibility(View.INVISIBLE);
        }else {
            NIng.setVisibility(View.VISIBLE);
            SimIng.setVisibility(View.INVISIBLE);
        }}
    });}
        public void Fra(){
            CheckFran.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(CheckFran.isChecked()){
                        SimF.setVisibility(View.VISIBLE);
                        NFran.setVisibility(View.INVISIBLE);
                    }else {
                        NFran.setVisibility(View.VISIBLE);
                        SimF.setVisibility(View.INVISIBLE);
                    }}
            });}
            public void Esp(){
                CheckEsp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if(CheckEsp.isChecked()){
                            SimE.setVisibility(View.VISIBLE);
                            NEsp.setVisibility(View.INVISIBLE);
                        }else {
                            NEsp.setVisibility(View.VISIBLE);
                            SimE.setVisibility(View.INVISIBLE);
                        }}
                });}
                public void Out(){
                    CheckOut.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            if(CheckOut.isChecked()){
                                SimO.setVisibility(View.VISIBLE);
                                NOut.setVisibility(View.INVISIBLE);
                            }else {
                                NOut.setVisibility(View.VISIBLE);
                                SimO.setVisibility(View.INVISIBLE);
                            }}
                    });}
                    public void Pot(){
                        CheckPot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                if(CheckPot.isChecked()){
                                    SimP.setVisibility(View.VISIBLE);
                                    NPot.setVisibility(View.INVISIBLE);
                                }else {
                                    NPot.setVisibility(View.VISIBLE);
                                    SimP.setVisibility(View.INVISIBLE);
                                }}
                        });




    }





    }